This folder contains the platform abstract layer for multiple platforms.  To support a new platform, you can simply create a new folder here and implement all the APIs defined in [`include`](./include) folder.



Refer to [port_wamr.md](../../../doc/port_wamr.md) for how to port WAMR to a target platform.





