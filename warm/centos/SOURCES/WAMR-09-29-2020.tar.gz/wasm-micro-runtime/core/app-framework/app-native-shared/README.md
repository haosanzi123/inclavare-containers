 Notes:
=======
This folder is for the source files shared by both WASM APP and native runtime

- The c files in this directory are compiled into both the WASM APP and runtime. 
- The header files for distributing to SDK are placed in the "bi-inc" folder.





