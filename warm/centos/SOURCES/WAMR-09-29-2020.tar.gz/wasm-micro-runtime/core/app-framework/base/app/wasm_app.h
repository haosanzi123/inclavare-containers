/*
 * Copyright (C) 2019 Intel Corporation.  All rights reserved.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 */

#ifndef _LIB_AEE_H_
#define _LIB_AEE_H_

#include "bi-inc/shared_utils.h"
#include "bi-inc/attr_container.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /* end of _LIB_AEE_H_ */
