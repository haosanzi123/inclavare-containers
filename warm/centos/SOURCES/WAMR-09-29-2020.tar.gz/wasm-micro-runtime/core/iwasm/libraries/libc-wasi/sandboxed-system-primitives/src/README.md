This directory consists of selected files copied from the [src/libemulator]
directory in the [cloudabi-utils] repository, with minor modifications,
along with the accompanying LICENSE file from that repository.

The modifications are marked with `WASMTIME_*` preprocessor macros.

The files were copied at git revision
223dadc53248552db43e012c67ed08cf416a2b12
which is dated
Tue Jun 25 17:22:07 2019 -0700
.

[libemulator]: https://github.com/NuxiNL/cloudabi-utils/tree/223dadc53248552db43e012c67ed08cf416a2b12/src/libemulator
[cloudabi-utils]: https://github.com/NuxiNL/cloudabi-utils
