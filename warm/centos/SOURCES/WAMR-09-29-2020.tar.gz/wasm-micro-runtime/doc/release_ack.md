Major feature releases and contributors
=========================================


**May 07, 2019: WAMR first GitHub release**

- Contributors: Wenyong Huang, Weining Lu, Lei Shi, Li Tian, Jizhao Zhang, Yi Zhang, Daoming Qiu, Xin Wang (Intel)

**May 17, 2019: Application manager, WASM APP API, samples and test tools**

- Contributors: Wenyong Huang, Weining Lu, Lei Shi, Li Tian, Jizhao Zhang, Yi Zhang, Daoming Qiu, Xin Wang (Intel)


**May 23, 2019: Support AliOS Things**

- Contributor: JinZhou Zhu (Alibaba)

**May 24, 2019: Support memory usage profiler**

- Contributors Wenyong Huang (Intel)

**Jun 11, 2019: Add WASM APP API connection**


- Contributor: Weining Lu (Intel)

**Jun 10, 2019: Support VxWorks**

- Contributor: Yiting Wang (WindRiver)

**Aug 1, 2019: Add WGL graphic user interface API**

- Contributor: Weining Lu

**Aug 14, 2019: Add Docker support**


- Contributor: beriberikix


**Aug 14, 2019: WASM IoT app store demo**


- Contributor: Luhanzhi Li, Jun Xu (Intel)


**Aug 28, 2019: SGX support**


- Contributor: Mic Bowman (Intel)


**Sep 6, 2019: Mac platform support**


- Contributor: Jonathan Dong (Alibaba)

**Nov 2019: WASI support** (Intel)

**Jan 2020: Ahead of time and Just-in-Time compilation support** (Intel)

