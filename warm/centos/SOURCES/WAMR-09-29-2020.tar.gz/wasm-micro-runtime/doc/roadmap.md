
# WebAssembly Micro Runtime Roadmap



## Data serialization
Evaluating using cbor as the default data serialization

No plan yet.



## Threading
Plan: 2020 Q1



## AssemblyScript Support and API

Currently under evaluation



