/*
 * Copyright (C) 2019 Intel Corporation.  All rights reserved.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 */

#include "stdio.h"
#include "string.h"

void print_line(char* str)
{
    printf("%s\n", str);
}