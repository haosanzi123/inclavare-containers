int
A()
{
    return 10;
}