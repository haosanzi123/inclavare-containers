/*
 * Copyright (C) 2019 Intel Corporation.  All rights reserved.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 */
#ifndef __BOARD_CONFIG_H__
#define __BOARD_CONFIG_H__
#include "pin_config_stm32.h"

#endif /* __BOARD_CONFIG_H__ */
